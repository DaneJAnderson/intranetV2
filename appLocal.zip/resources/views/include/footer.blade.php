
<footer-component ></footer-component>


{{-- v-if="this.$route.name == 'Home'" id="secFooter" --}}