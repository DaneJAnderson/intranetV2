<?php
/**
*	Author: Gavin Palmer
*	Author URL: http://www.gp-tech-co.com
*	License: 
*	License URL: 
*/
namespace App\Exceptions;

use Exception;
/*use DB;
use File;
use Storage;*/

class customValidationException extends Exception
{
	
}
